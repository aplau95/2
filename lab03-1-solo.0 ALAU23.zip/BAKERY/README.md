Andrew Lau
alau23@calpoly.edu

Build instructions in order
1. source BAKERY-setup.sql
2. source BAKERY-build-Customers.sql
3. source BAKERY-build-Goods.sql
4. source BAKERY-build-Receipts.sql
5. source BAKERY-build-Items.sql

Modify Program (modifies Goods)
1. source BAKERY-modify.sql

Cleanup
1. source BAKERY-cleanup.sql