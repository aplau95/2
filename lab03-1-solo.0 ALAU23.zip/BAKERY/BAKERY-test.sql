SELECT * FROM Customers;
SELECT * FROM Goods;
SELECT * FROM Items;
SELECT * FROM Receipts;