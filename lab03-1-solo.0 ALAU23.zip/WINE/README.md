Andrew Lau
alau23@calpoly.edu

Build instructions in order
1. source WINE-setup.sql
2. source WINE-build-Appellations.sql
3. source WINE-build-Grapes.sql
4. source WINE-build-Wine.sql

Modify Program (modifies Goods)
1. source WINE-modify.sql

Cleanup
1. source WINE-cleanup.sql