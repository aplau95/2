SELECT * FROM Appellations;
SELECT * FROM Grapes;
SELECT * FROM Wine;